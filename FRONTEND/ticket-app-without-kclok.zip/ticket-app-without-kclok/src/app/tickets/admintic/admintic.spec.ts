import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Admintic } from './admintic';

describe('Admintic', () => {
  let component: Admintic;
  let fixture: ComponentFixture<Admintic>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Admintic]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Admintic);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
