import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApplicationService } from '../../services/application-service';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { HeaderComponent } from 'src/app/components/header';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { SidebarComponent } from 'src/app/components/sidebar';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { EditAppDialog } from 'src/app/applications/edit-app-dialog/edit-app-dialog';

@Component({
  selector: 'app-ticket-details',
  imports:[CommonModule,
    ReactiveFormsModule,
    FormsModule,
    MatCardModule,
    HeaderComponent,
    SidebarComponent,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule

  ],
  templateUrl: 'ticket-details.html',
  styleUrls: ['ticket-details.css']
})
export class TicketDetails implements OnInit {
  ticket: any = null;
  editMode = false;
  ticketForm!: FormGroup;
  sidebarCollapsed: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private applicationService: ApplicationService,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.applicationService.getTicketById(+id).subscribe(ticket => {
        console.log(ticket)
        this.ticket = ticket;
        this.ticketForm = this.fb.group({
          title: [ticket.title, [Validators.required, Validators.minLength(5)]],
          description: [ticket.description, [Validators.required, Validators.minLength(10)]],
          importance: [ticket.importance, Validators.required]
        });
      });
    }
  }

  enableEdit() {
    this.editMode = true;
    this.ticketForm.enable();
  }

  saveEdit() {
    if (this.ticketForm.valid) {
      this.applicationService.editTicket(this.ticket.id, this.ticketForm.value).subscribe(() => {
        this.editMode = false;
        Object.assign(this.ticket, this.ticketForm.value);
      });
    }
  }

  cancelEdit() {
    this.editMode = false;
    this.ticketForm.patchValue({
      title: this.ticket.title,
      description: this.ticket.description,
      importance: this.ticket.importance
    });
  }

  toggleSidebar() {
    this.sidebarCollapsed = !this.sidebarCollapsed;
  }

  navigateToApplication() {
    this.router.navigate(['/applications/apps']);
  }

  navigateToFeature() {
    this.router.navigate(['/features/features']);
  }

  navigateToTicket() {
    this.router.navigate(['/tickets/tickets']);
  }

  navigateToFeedback() {
    this.router.navigate(['/feedback/appfeedback']);
  }
}
