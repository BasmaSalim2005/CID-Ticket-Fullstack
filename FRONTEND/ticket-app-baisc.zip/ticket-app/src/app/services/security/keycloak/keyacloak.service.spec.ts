import { TestBed } from '@angular/core/testing';

import { KeyacloakService } from './keyacloak.service';

describe('KeyacloakService', () => {
  let service: KeyacloakService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(KeyacloakService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
