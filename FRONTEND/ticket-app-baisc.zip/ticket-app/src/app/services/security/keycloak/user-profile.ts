export class UserProfile{
    firstname?:string;
    lastname?:string;
    fullname?:string;
    username?:string;
    email?:string;
    role!:string;

    



}