import { Injectable } from '@angular/core';
import Keycloak from 'keycloak-js';
import { Router } from '@angular/router';
import { UserProfile } from './user-profile';
// import { UserResponse, UserService } from '../../userService/user-service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';

export interface UserResponse {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
}

@Injectable({
  providedIn: 'root',
})

export class KeycloakService {
  private usersReadySubject = new BehaviorSubject<boolean>(false);
  public usersReady$ = this.usersReadySubject.asObservable();

  private _keycloak: Keycloak;
  private _userProfile: UserProfile;
  public allUsersExceptMe: UserResponse[] = [];

  constructor(
    private router: Router,
  ) {}

  get keycloak() {
    if (!this._keycloak) {
      this._keycloak = new Keycloak({
        url: 'http://localhost:8081',
        realm: 'cid-apps',
        clientId: 'ticket-ux',
      });
    }
    return this._keycloak;
  }

  async init() {
    const authenticated = await this.keycloak.init({
      onLoad: 'login-required', //
    });

    if (authenticated) {
      this.initializeUserProfile();

      // Ne redirige que si l'utilisateur vient de se connecter, pas lors d'un refresh
      const isFirstLogin = !sessionStorage.getItem('alreadyLoggedIn');

      if (isFirstLogin) {
        sessionStorage.setItem('alreadyLoggedIn', 'true');

        const role = this.getUserRole().toLowerCase();
        this.router.navigate(['/applications/appsadmin']);
      }
      // Sinon, on ne fait rien, l'utilisateur reste sur la page actuelle
    }
  }

  initializeUserProfile() {
    const tokenParsed: any = this.keycloak.tokenParsed;

    const role = tokenParsed?.resource_access?.['ticket-ux']?.roles?.[0] || '';

    console.log("native token",this._keycloak.token)
    
    this._userProfile = {
      username: tokenParsed?.preferred_username || '',
      email: tokenParsed?.email || '',
      fullname: tokenParsed?.name || '',
      firstname: tokenParsed?.given_name || '',
      lastname: tokenParsed?.family_name || '',
      role: role,
    };

    console.log('Token parsed:', tokenParsed);
    console.log('Extracted role:', role);
    console.log('User profile:', this._userProfile);
  }

  getUserEmail() {
    this.initializeUserProfile();
    console.log('my email', this._userProfile.email);
    return this.userProfile.email;
  }

  getUserRole() {
    return this.userProfile.role;
  }

  get userProfile() {
    return this._userProfile;
  }

  async login() {
    await this.keycloak.login();
  }

  get userId(): string {
    return this.keycloak?.tokenParsed?.sub as string;
  }

  get isTokenValid(): boolean {
    return !this.keycloak.isTokenExpired();
  }

  logout() {
    return this.keycloak.logout({ redirectUri: 'http://localhost:4200' });
  }

  accountManagement() {
    return this.keycloak.accountManagement();
  }
}
