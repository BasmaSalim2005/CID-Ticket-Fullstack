import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, Router } from '@angular/router';
import { KeycloakService } from '../keycloak/keyacloak.service';

@Injectable({
  providedIn: 'root',
})
export class RoleGuard implements CanActivate {
  constructor(
    private keycloakService: KeycloakService,
    private router: Router
  ) {}

  canActivate(route: ActivatedRouteSnapshot): boolean {
    const expectedRole = route.data['expectedRole'];
    const userRole = this.keycloakService.getUserRole();

    if (userRole === expectedRole) {
      console.log('user role is ', userRole);
      return true;
    } else {
      this.router.navigate(['/dashboards/error401']); // créer cette page
      return false;
    }
  }
}
