import { Component } from '@angular/core';

@Component({
  selector: 'app-admintic',
  standalone: false,
  templateUrl: './admintic.html',
  styleUrl: './admintic.css'
})
export class Admintic {

}
