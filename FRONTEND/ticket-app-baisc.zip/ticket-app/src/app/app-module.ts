import { APP_INITIALIZER, NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing-module';
import { App } from './app';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatDialogModule } from '@angular/material/dialog';
import { SidebarComponent } from './components/sidebar';
import { HeaderComponent } from './components/header';
import { Tickets } from './tickets/tickets';

import { Appfeedback } from './feedback/appfeedback/appfeedback';
import { TicketDetails } from './tickets/ticdetails/ticket-details';
import { Addfeedback } from './feedback/add-feedback/addfeedback';
import { Admintic } from './tickets/admintic/admintic';
import { KeycloakService } from './services/security/keycloak/keyacloak.service';
import { KeycloakHttpInterceptor } from './services/security/http/keycloak-http.interceptor';

export function initializeKeycloak(keycloak: KeycloakService) {
  return () => keycloak.init();
}
@NgModule({
  declarations: [
    App,
    Admintic,
 
    // Appfeedback,
      //  Addfeedback,
    // Tickets
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    SidebarComponent,
    HeaderComponent,
    MatCardModule,
    MatIconModule,
    MatDialogModule
  ],
  // providers: [
  //   provideBrowserGlobalErrorListeners()
  // ],
  providers: [
    //added keycloak here
    KeycloakService,
    {
      provide: APP_INITIALIZER,
      useFactory: initializeKeycloak,
      multi: true,
      deps: [KeycloakService],
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: KeycloakHttpInterceptor,
      multi: true,
    },
  ],
  bootstrap: [App]
})
export class AppModule { }
